import numpy as np
import pandas as pd
import matplotlib.pyplt as plt
def normalizeEquation(X,y):
    theta=np.linalg.inv(X.T@X)@X.T@y
    return theta
