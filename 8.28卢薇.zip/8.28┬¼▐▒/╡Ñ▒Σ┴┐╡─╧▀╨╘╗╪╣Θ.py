import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data=pd.read_csv('ex1data1.txt',names=['popelation','profit'])

data.head()



data.plot.scatter('population','profit',label='population')
plt.show()

data.insert(0,'ones',1)
data.head()

X=data.iloc[:,0:-1]
X.head()

y=data.iloc[:,-1]
y.head()

X=X.values


y=y.values


y=y.reshape(97,1)


def costFunction(X,y,theta):
    inner=np.power(X@theta-y,2)
    return np.sum(inner)/(2*len(X))
theta=np.zeros((2,1))
def gradientDescent(X,y,theta,alpha,iters):
    costs=[]

    for i in range(iters):
        theta=theta-(X.T@(X@theta-y))*alpha/len(X)
        cost=costFunction(X,y,theta)
        costs.append(cost)

        if i%100==0:
            print(cost)

    return theta,costs

alpha=0.02
costs=20000
iters=2000

theta,cost=gradientDescent(X,y,theta,alpha,iters)

fig,ax=plt.subplots()
ax.plot(np.arange(iters),costs)
ax.set(xlabel='iters',
       ylabel='cost',
       title='cost vs iters')
plt.show()

x=np.linspace(y.min(),y.max(),100)
y_=theta[0,0]+theta[1,0]*x



fig,ax=plt.subplots()
ax.scatter(X[:,1],y,label='training')
ax.plot(x.y_,'r',label='predict')
ax.legend()
ax.set(xlabel='population',
       ylabel='profit')






