import numpy as np
import pandas as pd
import matplotlib.pyplt as plt
data=pd.read_csv('ex1data2.txt',name=['size','bedrooms','price'])
data.head()

def normalize_feature(data):
    return (data-data.mean())/data.std()

data=normalize_feature(data)
data.head()

data.polt.scatter('size','price',label='size')
plt.show()

data.polt.scatter('bedrooms','price',label='bedrooms')
plt.show()

# 添加全为1的列
data.insert(0,'ones',1)

X=data.iloc[:,0:-1]

y=data.iloc[:,-1]

# data转为数组
X=X.values

y=y.values

y=y.reshape(47,1)

##  损失函数
def costFunction(X,y,theta):
    inner=np.power(X@theta-y,2)
    return np.sum(inner)/(2*len(X))

theta=np.zeros((3,1))
cost_init=costFunction(X,y,theta)
def gradientDescent(X,y,theta,alpha,iters):
    costs=[]

    for i in range(iters):
        theta=theta-(X.T@(X@theta-y))*alpha/len(X)
        cost=costFunction(X,y,theta)
        costs.append(cost)

        if i%100==0:
            print(cost)

    return theta,costs

# 不同alpha下的一个效果
candinate_alpha=[0.0003,0.003,0.03,0.0001,0.001,0.01]
iters=2000

fig,ax=plt.subplots()

for alpha in candinate_alpha:
    _, costs = gradientDescent(X, y, theta, alpha, iters)
    ax.plot(np.arange(iters),costs)
ax.plot(np.arange(iters),costs,label=alpha)
ax.legend()

ax.set(xlabel='iters',
       ylabel='cost',
       title='cost vs iters')
plt.show()
