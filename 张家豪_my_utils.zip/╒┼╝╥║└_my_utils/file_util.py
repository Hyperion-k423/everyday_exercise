def print_file_info(file_name):
    """
    功能是：将给定路径的文件内容输出到控制台中
    :param file_name:即将被读取的文件路径
    :return:None
    """
    f = None
    try:
        f = open(file_name, "r", encoding="UTF-8")
        print(f"文件的内容如下{f.read()}")
    except Exception as e:
        print(f"捕获到异常,原因是{e}")
    finally:
        if f:           #如果变量是None，那么就是False。如果有如何内容，就是True
            f.close()

def append_to_file(file_name,data):
    """
    功能：将指定的数据追加到指定的文件中
    :param file_name:指定的文件路径
    :param data:指定的数据
    :return:None
    """
    f = open(file_name,"a",encoding="UTF-8")
    f.write(data)
    f.write("\n")
    f.close()
if __name__ == '__main__':
    print_file_info("D:\\TEST.txt")
    append_to_file("D:\\TEST.txt","网易零")
