def str_reverse(s):
    """
    功能是将字符串完成反转操作
    :param s:将被反转的字符串
    :return:反转后的字符串
    """
    result = s[::-1]
    return result
def substr(s,x,y):
    """
    按照给定的下标完成给定的字符串切片操作
    :param s: 给定的字符串
    :param x: 切片开始的下标
    :param y:切片结束的下标
    :return:切片完成后的字符串
    """
    result = s[x:y]
    return result
if __name__ == '__main__':
    print(str_reverse("黑马字符串"))
    print(substr("黑马程序员",1,3))