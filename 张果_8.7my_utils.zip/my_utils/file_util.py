def print_file_info(file_name):
    #接收传入文件的路径，打印文件的全部内容，如文件不存在则捕获异常，输出提示信息，通过finally关闭文件对象函数
    f=None
    try:
        f=open(file_name,"r",encoding='UTF-8')
        print(f"{f.read()}")
    except Exception as e:
        print(f"异常为{e}")
    finally:
        if f:
            f.close()
            #如果文件不为空再关闭

def append_to_file(file_name,date):
    f = None
    try:
        f = open(file_name, "a", encoding="UTF-8")
        f.write(date)
        f.write(("\n"))
    except Exception as e:
        print(f"异常为{e}")
    finally:
        if f:
            f.close()
            # 如果文件不为空再关闭

if __name__ == '__main__':
    print_file_info("D:\wenben\\bill.txt")
    append_to_file("D:\wenben\\bill.txt", "date")
    f=open('D:\wenben\\bill.txt', 'r', encoding='UTF_8')
    print(f"追加date后为：{f}")
    f.close()