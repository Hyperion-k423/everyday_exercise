def str_reverse(s):
    #接受传入字符串，将字符串反转返回
    return s[::-1]
def substr(s,x,y):
    #按照下标x和y，对字符串进行切片
    return s[x:y:]

if __name__ == '__main__':
    s="abcd"
    print(f"{str_reverse(s)}")
    print(f"{substr(s,1,3)}")