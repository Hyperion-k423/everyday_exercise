#存储所有游戏运行的函数
import sys
import pygame
from bullet import Bullet
from alien import Ailen
import time
#开火
def fire_bullet(ai_settings,screen,ship,bullets):
    if len(bullets)<ai_settings.bullets_allowed:
        new_bullet = Bullet(ai_settings,screen,ship)
        bullets.add(new_bullet)

def check_keydown_events(event,ai_settings,screen,ship,bullets):
    if event.key == pygame.K_RIGHT:
        ship.moving_right = True
    if event.key == pygame.K_LEFT:
        ship.moving_left = True
    if event.key == pygame.K_SPACE:
        fire_bullet(ai_settings,screen,ship,bullets)


def check_keyup_events(event,ship):
    if event.key == pygame.K_RIGHT:
        ship.moving_right = False
    if event.key == pygame.K_LEFT:
        ship.moving_left = False

#左右键，实现飞船移动
def check_events(ai_settings,screen,stats,sb,play_button,ship,aliens, bullets):
    #检测所有事件
    for event in  pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            check_keydown_events(event,ai_settings,screen,ship,bullets)
            if event.key ==pygame.K_m:
                ai_settings.bullet_width = 400
            if event.key ==pygame.K_n:
                ai_settings.bullet_width = 3
        elif event.type == pygame.KEYUP:
            check_keyup_events(event,ship)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x,mouse_y =   pygame.mouse.get_pos()
            check_play_button(ai_settings,screen,stats,sb,play_button,ship,aliens, bullets,mouse_x,mouse_y)

def check_play_button(ai_settings,screen,stats,sb,play_button,ship,aliens, bullets,mouse_x,mouse_y):
    if play_button.rect.collidepoint(mouse_x,mouse_y) and stats.game_active==False:

        pygame.mouse.set_visible(False)

        ai_settings.init_dynamic_settings()

        stats.game_active = True
        stats.resset_stats()

        sb.prep_score()
        sb.prep_height_score()
        sb.prep_level()
        sb.prep_ships()

        bullets.empty()
        aliens.empty()
        create_fleet(ai_settings,screen,ship,aliens)
        ship.center_ship()

def update_screen(ai_settings,screen,stats,ship,bullets,aliens,play_button,sb):
    #设置背景色
    screen.fill(ai_settings.bg_color)
    sb.show_score()
    for bullet in bullets.sprites():
        bullet.draw_bullet()

    ship.blitme()
    for alien in aliens:
        alien.blitme()
    if stats.game_active==False:
        play_button.draw_button()
        pygame.mouse.set_visible(True)
    #显示屏幕
    pygame.display.flip()

def check_bullet_aliens_conllisions(ai_settings,screen,stats,sb,ship,aliens,bullets):

    conllisions = pygame.sprite.groupcollide(bullets,aliens,True,True)

    if conllisions:
        for aliens in conllisions.values():
            stats.score = stats.score+ai_settings.alien_points*len(aliens)
            sb.prep_score()
        check_height_score(stats,sb)
    if len(aliens)<=0:
        bullets.empty()
        ai_settings.increase_speed()
        stats.level = stats.level+1
        sb.prep_level()
        create_fleet(ai_settings,screen,ship,aliens)


def update_bulltes(ai_settings,screen,stats,sb,ship,aliens,bullets):
    for bullet in bullets:
        bullet.update()

    for bullet in bullets.copy():
        if bullet.rect.bottom<0:
            bullets.remove(bullet)
    check_bullet_aliens_conllisions(ai_settings,screen,stats,sb,ship,aliens,bullets)


def get_number_col(ai_settings,alien_width):
    available_space_x = ai_settings.screen_width - (alien_width*2)
    num_ailen_x = available_space_x/(alien_width*2)
    return num_ailen_x
def get_number_row(ai_settings,ship_height,alien_height):
    available_space_y = ai_settings.screen_height - ship_height - alien_height*3
    num_ailen_y = available_space_y/(alien_height*2)
    return num_ailen_y

def create_alien(ai_settings,screen,aliens,alien_num_x,alien_num_y):
    alien = Ailen(ai_settings,screen)
    alien_width = alien.rect.width
    alien_height = alien.rect.height
    alien.x =alien_width + alien_width*2*alien_num_x #
    alien.rect.x = alien.x
    alien.y =alien_height + alien_height*2*alien_num_y #
    alien.rect.y = alien.y
    aliens.add(alien)
def create_fleet(ai_settings,screen,ship,aliens):
    alien = Ailen(ai_settings,screen)
    num_ailen_col =   get_number_col(ai_settings,alien.rect.width)
    num_ailen_row =   get_number_row(ai_settings,ship.rect.height,alien.rect.height)
    for row in range(0,int(num_ailen_row)):
        for col in range(0,int(num_ailen_col)):
            create_alien(ai_settings,screen,aliens,col,row)
def update_aliens(ai_settings,stats,sb,screen,ship,aliens,bullets):
    check_feet_edges(ai_settings,aliens)

    for alien in aliens:
        alien.update()
    if pygame.sprite.spritecollideany(ship,aliens):
        ship_hit(ai_settings,stats,sb,screen,ship,aliens,bullets)
    check_aliens_bottom(ai_settings,stats,sb,screen,ship,aliens,bullets)

def check_feet_edges(ai_settings,aliens):
    for alien in aliens:
        if alien.check_edges():
            change_feet_direction(ai_settings,aliens)
            break

#改变方向
def change_feet_direction(ai_settings,aliens):
    for alien in aliens:
        alien.rect.y =  alien.rect.y + ai_settings.feet_drop_speed
    ai_settings.feet_direction =  ai_settings.feet_direction * -1

def ship_hit(ai_settings,stats,sb,screen,ship,aliens,bullets):
    if stats.ships_left>0:
        stats.ships_left = stats.ships_left-1
        sb.prep_ships()
    else:
        stats.game_active = False
        time.sleep(1)
    aliens.empty()
    bullets.empty()
    create_fleet(ai_settings,screen,ship,aliens)
    ship.center_ship()

    time.sleep(1)
def check_aliens_bottom(ai_settings,stats,sb,screen,ship,aliens,bullets):
    screen_rect = screen.get_rect()
    for alien in aliens:
        if alien.rect.bottom >=screen_rect.bottom:
            ship_hit(ai_settings, stats,sb, screen, ship, aliens, bullets)
            break
def check_height_score(stats,sb):
    if stats.score>stats.height_score:
        stats.height_score = stats.score
        sb.prep_height_score()





