class GameStats():
    def __init__(self,al_settings):
        self.al_settings = al_settings
        self.game_active = False
        self.height_score = 0
        self.resset_stats()
    #重新开始游戏
    def resset_stats(self):
        self.ships_left = self.al_settings.ship_limit
        #得分
        self.score = 0
        self.level = 1
