import pygame.font
from pygame.sprite import Group
from ship import Ship

class Scoreborad():
    def __init__(self,ai_settings,screen,stats):
        self.screen= screen
        self.screen_rect = screen.get_rect()
        self.ai_setting = ai_settings
        self.stats = stats
        self.text_color = (30,30,30)
        self.font=pygame.font.SysFont(None,48)
        self.prep_score()
        self.prep_height_score()
        self.prep_level()
        self.prep_ships()

    def prep_score(self):
        rounded_score = int(round(self.stats.score,-1))
        score_str =  "{:,}".format(rounded_score)
        self.score_img = self.font.render(score_str,True,self.text_color,self.ai_setting.bg_color)
        #调整位置
        self.score_rect = self.score_img.get_rect()
        self.score_rect.right =  self.screen_rect.right  - 20
        self.score_rect.top =  20

    def prep_height_score(self):

        rounded_score = int(round(self.stats.height_score,-1))
        score_str =  "{:,}".format(rounded_score)
        self.score_height_img = self.font.render(score_str,True,self.text_color,self.ai_setting.bg_color)

        self.score_height_rect = self.score_height_img.get_rect()
        self.score_height_rect.right =  self.screen_rect.centerx
        self.score_height_rect.top =  20

    def prep_level(self):
        self.level_img = self.font.render(str(self.stats.level),True,self.text_color,self.ai_setting.bg_color)

        self.level_img_rect = self.level_img.get_rect()
        self.level_img_rect.right =  self.screen_rect.right - 20
        self.level_img_rect.top =  self.score_rect.bottom+10

    def show_score(self):
        self.screen.blit(self.score_img,self.score_rect)
        self.screen.blit(self.score_height_img,self.score_height_rect)
        self.screen.blit(self.level_img,self.level_img_rect)
        self.ships.draw(self.screen)

    def prep_ships(self):
        self.ships = Group()
        for ship_num in range(0,self.stats.ships_left):
            ship = Ship(self.ai_setting,self.screen)
            ship.rect.x = 10+ship_num*ship.rect.width
            ship.rect.y = 10
            self.ships.add(ship)