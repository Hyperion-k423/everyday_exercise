
import sys
import pygame

from random import randint
from bullet import Bullet
from alien import Alien
from time import sleep


def fire_bullet(ai_settings, screen, ship, bullets, stats):
    """开火！"""
    # 确保屏幕上的子弹数在限制范围内
    for i in range(int(stats.level / 5) + 1):
        if len(bullets) < ai_settings.bullet_allowed:
            new_bullet = Bullet(ai_settings, screen, ship)
            bullets.add(new_bullet)


def check_keydown(event, ai_settings, screen, ship, bullets, stats):
    """检查用户按键是否按下以及执行的任务"""
    if event.key == pygame.K_RIGHT:
        ship.moving_right = True

    elif event.key == pygame.K_LEFT:
        ship.moving_left = True

    elif event.key == pygame.K_UP:
        ship.moving_up = True

    elif event.key == pygame.K_DOWN:
        ship.moving_down = True

    elif event.key == pygame.K_SPACE:
        # 发射一颗子弹，并且在限制范围内
        fire_bullet(ai_settings, screen, ship, bullets, stats)


def check_keyup(event, ship):
    """检查用户释放按键"""
    if event.key == pygame.K_RIGHT:
        ship.moving_right = False

    elif event.key == pygame.K_LEFT:
        ship.moving_left = False

    elif event.key == pygame.K_UP:
        ship.moving_up = False

    elif event.key == pygame.K_DOWN:
        ship.moving_down = False


def check_events(ai_settings, screen, ship, aliens, bullets, stats, play_button, sb):
    """响应键盘和鼠标事件"""
    for event in pygame.event.get():
        if event.type == pygame.K_q:
            sys.exit()
        # 如果一直按下右键或者左键，空格键，则向右或右移动或者开火
        elif event.type == pygame.KEYDOWN:
            check_keydown(event, ai_settings, screen, ship, bullets, stats)

        # 释放右键或左键，停止移动
        elif event.type == pygame.KEYUP:
            check_keyup(event, ship)

        # 点击Play按钮，开始游戏
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            check_play_button(ai_settings, screen, ship, aliens, bullets,
                              stats, play_button, mouse_x, mouse_y, sb)


def check_play_button(ai_settings, screen, ship, aliens, bullets,
                      stats, play_button, mouse_x, mouse_y, sb):
    """在玩家单击Play按钮时开始游戏"""
    button_clicked = play_button.rect.collidepoint(mouse_x, mouse_y)
    if button_clicked and not stats.game_active:
        # 重置游戏设置
        ai_settings.init_dynamic_settings()
        # 隐藏光标
        pygame.mouse.set_visible(False)
        # 重置游戏统计信息
        stats.reset_stats()
        stats.game_active = True

        # 重置记分牌图像
        sb.prep_score()
        sb.prep_high_score(screen)
        sb.prep_level()
        sb.prep_ships(screen)

        # 清空外星人和子弹列表
        aliens.empty()
        bullets.empty()

        # 创建一群新的外星人，并让飞船居中
        creat_fleet(ai_settings, screen, ship, aliens)
        ship.center_ship(ai_settings)


def update_screen(ai_settings, screen, ship, aliens, bullets, stats, play_button, sb):
    """每次循环都重绘屏幕"""
    screen.fill(ai_settings.bg_color)
    for bullet in bullets.sprites():
        bullet.draw_bullet()
    ship.blitme()
    aliens.draw(screen)
    sb.show_score()

    # 如果游戏处于非活动状态，绘制Play按钮
    if not stats.game_active:
        play_button.draw_button()

    """"刷新屏幕，擦去旧屏幕，显示新屏幕"""
    pygame.display.flip()


def update_bullet(ai_settings, screen, ship, aliens, bullets, stats, sb):
    """更新子弹位置，并删除已经消失的子弹"""
    # 更新子弹位置
    bullets.update()
    # 删除消失的子弹
    for bullet in bullets.copy():
        if bullet.rect.bottom <= 0:
            bullets.remove(bullet)
    # 检查是否有子弹击中外星人
    check_bullet_alien_colide(ai_settings, screen, ship, aliens, bullets, stats, sb)


def get_number_aliens_x(ai_settings, alien_width):
    """获得水平方向上外星人个数"""
    available_space_x = ai_settings.screen_width - 2 * alien_width
    number_aliens_x = int(available_space_x / (2 * alien_width))
    return number_aliens_x


def get_space_rows(ai_settings, ship_height, alien_height):
    """获得垂直方向上外星人的行数"""
    available_space_y = (ai_settings.screen_height - (3 * alien_height) -
                         ship_height)
    number_aliens_rows = int(available_space_y / (2 * alien_height))
    return number_aliens_rows


def creat_alien(ai_settings, screen, aliens, alien_number, row_number):
    """根据传入的数据在某个位置创建一个外星人"""
    alien = Alien(ai_settings, screen)
    alien_width = alien.rect.width
    alien.x = alien_width + 2 * alien_width * alien_number
    alien.rect.x = alien.x
    alien.rect.y = (alien.rect.height + 20) + 2 * alien.rect.height * row_number
    aliens.add(alien)


def creat_random_alien_x(number_aliens_x, ai_settings, screen, aliens, row_number):
    """在第一行随机创建若干个外星人"""
    for i in range(2, number_aliens_x + 2):
        random_number_x = randint(2, i)
        for alien_number in range(random_number_x - 1, random_number_x):
            creat_alien(ai_settings, screen, aliens, alien_number, row_number)


def creat_fleet(ai_settings, screen, ship, aliens):
    """创建外星人群以及获取屏幕上最大的行数和每行最多个数"""
    alien = Alien(ai_settings, screen)
    number_aliens_x = get_number_aliens_x(ai_settings, alien.rect.width)
    number_rows = get_space_rows(ai_settings, ship.rect.height,
                                 alien.rect.height)
    """随机创建行数"""
    for j in range(0, number_rows):
        random_number_y = randint(0, j)
        for row_number in range(random_number_y):
            creat_random_alien_x(number_aliens_x, ai_settings,
                                 screen, aliens, row_number)


def check_fleet_edges(ai_settings, aliens):
    """有外星人到达屏幕边缘"""
    for alien in aliens.sprites():
        if alien.check_edges():
            change_fleet_direction(ai_settings, aliens)
            break


def change_fleet_direction(ai_settings, aliens):
    """将外星人下移，并改变它们的方向"""
    for alien in aliens.sprites():
        alien.rect.y += ai_settings.fleet_drop_speed
    ai_settings.fleet_direction *= -1


def update_aliens(ai_settings, screen, ship, aliens, stats, bullets, sb):
    """检测有外星人位于屏幕边缘或者相撞或者外星人到达底部，更新外星人的位置"""
    check_fleet_edges(ai_settings, aliens)
    aliens.update()

    # 检测飞船与外星人的撞击
    if pygame.sprite.spritecollideany(ship, aliens):
        ship_hit(ai_settings, screen, ship, aliens, stats, bullets, sb)
    # 检查是否有外星人到达屏幕底部
    check_aliens_bottom(ai_settings, screen, ship, aliens, stats, bullets, sb)


def check_bullet_alien_colide(ai_settings, screen, ship, aliens, bullets, stats, sb):
    """检测子弹和外星人的碰撞"""
    collisions = pygame.sprite.groupcollide(bullets, aliens, True, True)
    # 两个True可使得子弹与外星人碰撞后消失，并返回一个字典
    # 碰撞之后加分
    if collisions:
        for aliens in collisions.values():
            i = randint(0, 10)
            if i > 8:
                stats.score += (ai_settings.alien_points + 10) * len(aliens)
                sb.prep_score()
            else:
                stats.score += ai_settings.alien_points * len(aliens)
                sb.prep_score()
        # 检查是否刷新最高分
        check_high_score(stats, sb, screen)

    if len(aliens) == 0:
        # 删除现有的子弹，加快游戏速度,创建新的外星人
        ship.center_ship(ai_settings)
        bullets.empty()
        ai_settings.increase_speed()
        # 提高等级
        stats.level += 1
        ai_settings.increase_bullet_size()
        sb.prep_level()

        creat_fleet(ai_settings, screen, ship, aliens)


def ship_hit(ai_settings, screen, ship, aliens, stats, bullets, sb):
    """飞船与外星人相撞，生命减1，清除外星人和子弹列表
    并创建新的外星人，飞船放在屏幕底部中央位置"""
    if stats.ship_left > 0:
        stats.ship_left -= 1
        sb.prep_ships(screen)
        # 清空外星人和子弹列表
        aliens.empty()
        bullets.empty()
        # 新建一个飞船和外星人群
        creat_fleet(ai_settings, screen, ship, aliens)
        ship.center_ship(ai_settings)
        # 暂停0.5秒
        sleep(0.5)
    else:
        ai_settings.bullet_width = 3
        stats.game_active = False
        pygame.mouse.set_visible(True)


def check_aliens_bottom(ai_settings, screen, ship, aliens, stats, bullets, sb):
    """检查是否有外星人到达底部"""
    screen_rect = screen.get_rect()
    for alien in aliens.sprites():
        if alien.rect.bottom >= screen_rect.bottom:
            ship_hit(ai_settings, screen, ship, aliens, stats, bullets, sb)
            break


def check_high_score(stats, sb, screen):
    """检查是否产生了新的最高分"""
    if stats.score > stats.high_score:
        stats.high_score = stats.score
        sb.prep_high_score(screen)