# 跟踪游戏的统计信息
class GameStats():
    """跟踪游戏的统计信息"""

    def __init__(self, ai_settings):
        self.ai_settings = ai_settings
        self.game_active = False
        self.reset_stats()

        # 任何情况下都不能重置最高分
        self.high_score = 0

    def reset_stats(self):
        """初始化在游戏运行过程中可能变化的统计信息"""
        self.ship_left = self.ai_settings.ship_limit
        self.score = 0
        self.level = 1
        self.bullet_width = 3