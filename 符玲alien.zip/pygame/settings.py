
class Settings():
    def __init__(self):
        """设置长度和宽度以及背景色属性"""
        self.screen_width = 800
        self.screen_height = 700
        self.bg_color = (255, 255, 255)
        self.ship_limit = 2

        """子弹设置"""
        self.bullet_width = 3
        self.bullet_height = 15
        self.bullet_color = (60, 60, 60)
        self.bullet_allowed = 8

        """外星人移动设置"""
        self.fleet_drop_speed = 10
        """以什么样的速度加快游戏节奏"""
        self.speed_up_scale = 1.1
        self.init_dynamic_settings()

        """外星人点数的提高"""
        self.score_scale = 1.5

        """子弹大小提高"""
        self.bullet_scale = 10

    def init_dynamic_settings(self):
        self.speed = 1.5
        self.bullet_speed = 3
        self.alien_speed = 0.2
        # fleet_direction为1表示向右移动，-1表示向左移动
        self.fleet_direction = -1

        # 计分
        self.alien_points = 10

    def increase_speed(self):
        """提高速度设置和外星人点数设置"""
        self.speed *= self.speed_up_scale
        self.bullet_speed *= self.speed_up_scale
        self.alien_speed *= self.speed_up_scale

        self.alien_points = int(self.alien_points * self.score_scale)

    def increase_bullet_size(self):
        self.bullet_width += self.bullet_scale