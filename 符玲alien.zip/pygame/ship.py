import pygame

from pygame.sprite import Sprite


class Ship(Sprite):
    def __init__(self, ai_settings, screen):
        """初始化飞船并设置其初始位置"""
        super(Ship, self).__init__()
        self.screen = screen

        # 加载飞船图像并获取其外接矩形
        self.image = pygame.image.load('images/ship.bmp')
        self.rect = self.image.get_rect()  # 获取飞船的矩形
        self.screen_rect = screen.get_rect()  # 获取屏幕矩形

        self.ai_settings = ai_settings

        # 将每艘新飞船放在屏幕底部中央位置
        self.rect.centerx = self.screen_rect.centerx
        self.rect.centery = self.screen_rect.centery
        self.rect.bottom = self.screen_rect.bottom

        self.center_x = float(self.rect.centerx)
        self.center_y = float(self.rect.centery)
        """连续检测按键，设置未按下右键为False"""
        self.moving_right = False
        self.moving_left = False
        self.moving_up = False
        self.moving_down = False

    def update(self):
        """如果连续按方向键，则一直移动,并且不超过边界"""
        if self.moving_right and self.rect.right < self.screen_rect.right:
            self.center_x += self.ai_settings.speed

        # 使用两个if，这样玩家同时按下两个键，
        # 将先增大rect.centerx值，再降低，则飞船位置不变
        if self.moving_left and self.rect.left > 0:
            self.center_x -= self.ai_settings.speed

        if self.moving_up and self.rect.top > 0:
            self.center_y -= self.ai_settings.speed

        if self.moving_down and self.rect.bottom < self.screen_rect.bottom:
            self.center_y += self.ai_settings.speed

        self.rect.centerx = self.center_x
        self.rect.centery = self.center_y

    """在指定位置绘制飞船"""

    def blitme(self):
        self.screen.blit(self.image, self.rect)

    def center_ship(self, ai_settings):
        self.center_x = ai_settings.screen_width / 2
        self.center_y = ai_settings.screen_height - 28